#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
    int cd = channel_create();
    if (cd < 0) {
        printf("Failed to create channel\n");
        exit(1);
    }
    if (fork() == 0) {
        if (channel_put(cd, 42) < 0) {
            printf("Papa: Failed to put data 42 in channel\n");
            exit(1);
        }
        //printf("Papa: I put data 42 in channel!\n");
        if (channel_put(cd, 43) < 0){
            printf("Papa: Failed to put data 43 in channel\n");
            exit(1);
        }
        //printf("Papa: I put data 43 in channel!\n");
        sleep(10);
        if (channel_destroy(cd) < 0){
            printf("Papa: Failed to destroy the channel\n");
            exit(1);
        }
        //printf("Papa: I destroy the channel son, watch out!\n");
    } else {
        int data;
        if (channel_take(cd, &data) < 0) { // 42
            printf("Son: Failed to take data 42 from channel\n");
            exit(1);
        }
        printf("Son: received %d from Papa!\n", data);
        if (channel_take(cd, &data) < 0) { // 42
            printf("Son: Failed to take data 43 from channel\n");
            exit(1);
        }
        printf("Son: received %d from Papa!\n", data);
        if (channel_take(cd, &data) < 0) { // sleep until destroy
            printf("Son: Channel is destroyed!\n");
            exit(0);
        }
    }
    exit(0);
}

