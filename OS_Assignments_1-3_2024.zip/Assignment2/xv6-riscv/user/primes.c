#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "math.h"

int check_if_prime(int number){

    //double root = sqrt(number);

    for(int div=2; div <= number / 2; div++){
        if (number % div == 0){
            return 0;
        }
    }

    return 1;
}

void checker(int id, int channelInput, int channelOutput){
    // Do forever:
    //      Take from channel  
    //      Check if prime:
    //          Put in channel
    //          if exit from put with -1 -> destroy channel 1 and exit

    while(1){
        int number;
        int returnCode = channel_take(channelInput, &number);
        if (returnCode != 0){
            // Error -> channel destroyed by other checker
            return;
        }

        int prime = check_if_prime(number);
        if(prime){
            int returnCode2 = channel_put(channelOutput, number);
            if (returnCode2 != 0){
                // Error -> Channel destroyed
                int returnCodeDestroy = channel_destroy(channelInput);
                if (returnCodeDestroy != 0){
                    printf("error in channel_destroy() in checker\n");
                    //printf("Checker %d - PID: %d - Exit\n", id, getpid());
                }
                return;
            }
        }
    }
}

void printer(int channelInput){
    // for 100:
    //      Take number from channel
    //      print number
    // destroy channel and exit

    for(int count=1; count<=100; count++){
        int number;
        int returnCode = channel_take(channelInput, &number);
        if (returnCode != 0){
            printf("Error in channel_take in printer()\n");
        }

        printf("Prime %d: %d\n", count, number);
    }

    int returnCodeDestroy = channel_destroy(channelInput);
    if (returnCodeDestroy != 0){
        printf("error in channel_destroy() in printer\n");
        //printf("Printer - PID: %d - Exit\n", getpid());
    }
    return;
}

void generator(int channelOutput){
    // generate a number
    // put it in channel
    // if channel return -1 it's destroyed -> exit

    int number = 2;
    int returnCode = 0;
    do{
        returnCode = channel_put(channelOutput, number);
        number++;
    }
    while(returnCode != -1);

    return;
}

int
main(int argc, char *argv[])
{
    int numberOfCheckers = 3;
    
    if (argc == 2){
        numberOfCheckers = atoi(argv[1]);
    }

    // Create the channels
    int channel1 = channel_create();
    int channel2 = channel_create();


    // Create the checkers
    for(int i = 0; i < numberOfCheckers; i++){
        int checker_pid = fork();
        if (checker_pid == 0){
            checker(i, channel1, channel2);
            goto exit;
        }
    }

    // Create the printer
    int printer_pid = fork();
    if (printer_pid == 0){
        printer(channel2);
        goto exit;
    }

    // Start producing numbers
    generator(channel1);

    // Generator (Parent) wait for all
    int childPID = 0;
    int checkerNumber = 1;
    while((childPID = wait(0)) != -1){
        if(childPID == printer_pid){
            printf("Printer - PID: %d - Exit\n", childPID);
        }
        else{
            printf("Checker %d- PID: %d - Exit\n", checkerNumber, childPID);
            checkerNumber++;
        }
    }

    printf("Generator - PID: %d - Exit\n", getpid());

exit:
    exit(0);
}