#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"


// Old sys_exit
// uint64
// sys_exit(void)
// {
//   int n;
//   argint(0, &n);
//   exit(n);
//   return 0;  // not reached
// }

uint64
sys_exit(void)
{
  //get exit code
  int n;
  argint(0, &n);

  //get exit message
  uint64 addr;
  argaddr(1, &addr);

  // If exit message is 0 -> set default message
  if(!addr){
    char default_buffer[] = "No exit message";
    addr = (uint64)&default_buffer;
  }

  // Copy message (Passed/Default) to the PCB
  struct proc* proc = myproc();
  char* exit_buffer = proc->exit_msg;
  int copiedBytes = fetchstr(addr, exit_buffer, 31);
  //printf("exit()- exit_msg: %s\n", proc->exit_msg);
  //  Failed on copy
  if(copiedBytes <= 0){
    exit(-1);
  }

  // Successful exit
  exit(n);
  return 0; //not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

// Old wait
// uint64
// sys_wait(void)
// {
//   uint64 p;
//   argaddr(0, &p);
//   return wait(p);
// }

uint64
sys_wait(void)
{
  // Fetch PID to wait on
  uint64 p;
  argaddr(0, &p);

  // Fetch the exit message to the given pointer
  uint64 ep;
  argaddr(1, &ep);

  //call wait with passed PID and buffer address
  return wait(p, ep);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

// Task 2
uint64
sys_memsize(void)
{
  return myproc()->sz;
}

// Task 5
uint64
sys_set_affinity_mask(void)
{
  int affinity_mask;

  // fetch argument - affinity mask
  argint(0, &affinity_mask);

  // get current proc
  struct proc* p = myproc();

  // set affinity mask in the proc struct to the requested one
  acquire(&p->lock);
  p->affinity_mask = affinity_mask;
  release(&p->lock);

  return 1;
}