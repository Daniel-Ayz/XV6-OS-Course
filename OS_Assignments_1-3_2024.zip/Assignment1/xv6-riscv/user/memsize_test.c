#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
    //Current memory
    int initialMemorySize = memsize();
    printf("%d\n", initialMemorySize);

    //Allocate 20k bytes
    void* newMemory = malloc(20000);

    //Fetch and print new memory 
    int newMemorySize = memsize();
    printf("%d\n", newMemorySize);

    //Free the allocated 20k bytes
    free(newMemory);

    //Fetch and print final memory 
    int finalMemorySize = memsize();
    printf("%d\n", finalMemorySize);
    exit(0,"ok");
}
