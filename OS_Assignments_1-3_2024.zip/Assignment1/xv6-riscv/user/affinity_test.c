#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
    
    int affinity_mask = (1 << 2) | 1;
    //int affinity_mask = (1 << 1);

    set_affinity_mask(affinity_mask);

    while(1){
        int pid = getpid();
        printf("(affinity_test) PID: %d\n", pid);
    }

    return 0;
}
