#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
    
    int* mem = malloc(200);
    const char* def = "Default\0";
    memcpy(mem, def, strlen(def));
    
    int parent_pid = getpid();


    //fork
    int pid = fork();

    if(pid){
        //parent write string
        const char* hello = "Hello Child\0";
        memcpy(mem, hello, strlen(hello));

        printf("Parent wait\n");
        wait(0);
        printf("parent exit\n");
    }
    else{
        //child
        void* dst_va = map_shared_pages(parent_pid, mem, 200);
        sleep(1);
        printf("The shared string: %s\n", dst_va);
        printf("child exit\n");
    }

    exit(0);
}
