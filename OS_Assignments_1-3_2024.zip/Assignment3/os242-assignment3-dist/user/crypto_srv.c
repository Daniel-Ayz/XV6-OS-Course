#include "kernel/types.h"
#include "user/user.h"
#include "kernel/spinlock.h"
#include "kernel/sleeplock.h"
#include "kernel/fs.h"
#include "kernel/file.h"
#include "kernel/fcntl.h"

#include "kernel/crypto.h"

int main(void) {
  if(open("console", O_RDWR) < 0){
    mknod("console", CONSOLE, 0);
    open("console", O_RDWR);
  }
  dup(0);  // stdout
  dup(0);  // stderr

  printf("crypto_srv: starting\n");

  // TODO: implement the cryptographic server here
  if(getpid() != 2){
    exit(-1);
  }

  struct crypto_op* request;
  uint64 size;

  while(1){

    //map memory request
    uint64 res = take_shared_memory_request((void**)&request, &size);
    if(res){
      printf("Error making shared_memory_request!\n");
    }

    // check size
    if(request->key_size > 1000 || request->data_size > 100000){
      request->state = CRYPTO_OP_STATE_ERROR;
    }
    // check state
    else if(request->state != CRYPTO_OP_STATE_INIT){
      request->state = CRYPTO_OP_STATE_ERROR;
    }
    // check type
    else if(request->type != CRYPTO_OP_TYPE_ENCRYPT && request->type != CRYPTO_OP_TYPE_DECRYPT){
      request->state = CRYPTO_OP_STATE_ERROR;
    }
    // everything is fine :)
    else{
      //take sizes
      uint64 key_size = request->key_size;
      uint64 data_size = request->data_size;

      // encrypt|decrypt
      for(int i=0; i<data_size; i++){
        request->payload[key_size + i] = request->payload[key_size + i] ^ request->payload[i % key_size];
      }

      // signal finish operation
      asm volatile ("fence rw,rw" : : : "memory");
      request->state = CRYPTO_OP_STATE_DONE;
    }

    // unmap memory request
    remove_shared_memory_request(request, size);
  }

  exit(0);
}
