#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int BUFFER_SIZE = 500;

int
main(int argc, char *argv[])
{
    printf("Before First malloc: %d\n", memsize());
    
    int* mem = malloc(BUFFER_SIZE);
    const char* def = "Default\0";
    memcpy(mem, def, strlen(def));

    int parent_pid = getpid();

    int pid = fork();

    if(pid){
        //parent
        //printf("Parent sleep\n");
        sleep(2);

        // Read from mem new string
        printf("The shared string: %s\n", mem);

        wait(0);
        printf("parent exit\n");
    }
    else{
        //child

        //map
        //sleep(1);
        printf("Memory before map: %d\n", memsize());
        void* dst_va = map_shared_pages(parent_pid, mem, BUFFER_SIZE);
        printf("Memory after map: %d\n", memsize());

        const char* hello = "Hello daddy\0";
        memcpy(dst_va, hello, strlen(hello));

        // unmap 
        unmap_shared_pages(dst_va, BUFFER_SIZE);
        printf("Memory after unmap: %d\n", memsize());

        //malloc
        malloc(70000);
        printf("Memory after malloc(70000): %d\n", memsize());

        // exit
        printf("child exit\n");
    }



    exit(0);
}
